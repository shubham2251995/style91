<?php

namespace App\Livewire\Checkout;

use Livewire\Component;

class OrderConfirmation extends Component
{
    public function render()
    {
        return view('livewire.checkout.order-confirmation');
    }
}
