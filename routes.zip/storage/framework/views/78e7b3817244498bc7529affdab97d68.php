<?php
// Initialize variables with safe defaults
$siteName = config('app.name', 'Style91');
$seoTagsArray = [];
$headerMenu = null;

// Try to load services gracefully
try {
    $seoService = new \App\Services\SeoService();
    $seoTagsArray = $seoService->generateTags($product ?? null);
} catch (\Exception $e) {
    // SEO service unavailable, use defaults
    $seoTagsArray = [];
}

try {
    $headerMenu = \App\Models\Menu::where('location', 'header')->first();
} catch (\Exception $e) {
    // Menu unavailable
    $headerMenu = null;
}

$metaTitle = $seoTagsArray['title'] ?? $siteName;
$metaDescription = $seoTagsArray['description'] ?? 'Premium Streetwear Fashion';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($metaTitle); ?></title>
    
    
    <meta name="description" content="<?php echo e($metaDescription); ?>">
    
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'brand-500': '#FFD93D',
                        'brand-accent': '#FFD93D',
                        'accent-500': '#6BCF7F',
                        'electric-500': '#00E5FF',
                        'electric-400': '#33EBFF',
                    }
                }
            }
        }
    </script>
    
    
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="bg-black text-white antialiased" x-data="{ mobileMenuOpen: false, searchOpen: false }">
    
    
    <div wire:loading class="fixed top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-500 to-accent-500 z-[100] animate-pulse"></div>

    
    <?php echo $__env->make('components.header-vibrant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <main class="min-h-screen pt-[104px] md:pt-[120px] pb-16 px-4 md:px-6 lg:px-8">
        <?php echo e($slot); ?>

    </main>

    
    <?php echo $__env->make('components.footer-vibrant', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    
    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('cart-drawer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2098692914-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('quick-view', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2098692914-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    
    
    <script>
        window.addEventListener('quick-view', event => {
            const productId = event.detail.productId;
            if (productId) {
                Livewire.dispatch('openQuickView', { productId: productId });
            }
        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\style91\resources\views/components/layouts/app-vibrant.blade.php ENDPATH**/ ?>