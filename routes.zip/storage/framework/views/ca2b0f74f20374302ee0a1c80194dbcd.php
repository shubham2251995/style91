<?php if (isset($component)) { $__componentOriginal75e07e14a0fccb399ed46428b2ab70e6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal75e07e14a0fccb399ed46428b2ab70e6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app-vibrant','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app-vibrant'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<div>
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-12" wire:key="section-<?php echo e($section->id); ?>">
                <?php if($section->type === 'hero'): ?>
                    <?php echo $__env->make('components.sections.hero', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'flash_sale'): ?>
                    <?php echo $__env->make('components.sections.flash-sale', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'featured_collection'): ?>
                    <?php echo $__env->make('components.sections.featured-collection', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'deal_of_day'): ?>
                    <?php echo $__env->make('components.sections.deal-of-day', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'trending'): ?>
                    <?php echo $__env->make('components.sections.trending', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'limited_stock'): ?>
                    <?php echo $__env->make('components.sections.limited-stock', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'category_showcase'): ?>
                    <?php echo $__env->make('components.sections.category-showcase', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'coupon_banner'): ?>
                    <?php echo $__env->make('components.sections.coupon-banner', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'testimonials'): ?>
                    <?php echo $__env->make('components.sections.testimonials', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                
                <?php elseif($section->type === 'newsletter'): ?>
                    <?php echo $__env->make('components.sections.newsletter', ['section' => $section], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php elseif($section->type === 'banner'): ?>
                    <?php echo $__env->make('components.sections.banner', ['content' => $section->content], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php elseif($section->type === 'categories'): ?>
                    <?php echo $__env->make('components.sections.categories', ['content' => $section->content, 'title' => $section->title], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php elseif($section->type === 'featured_products'): ?>
                    <?php echo $__env->make('components.sections.featured-products', ['content' => $section->content, 'title' => $section->title], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal75e07e14a0fccb399ed46428b2ab70e6)): ?>
<?php $attributes = $__attributesOriginal75e07e14a0fccb399ed46428b2ab70e6; ?>
<?php unset($__attributesOriginal75e07e14a0fccb399ed46428b2ab70e6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal75e07e14a0fccb399ed46428b2ab70e6)): ?>
<?php $component = $__componentOriginal75e07e14a0fccb399ed46428b2ab70e6; ?>
<?php unset($__componentOriginal75e07e14a0fccb399ed46428b2ab70e6); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\style91\resources\views/livewire/home.blade.php ENDPATH**/ ?>