<div><?php echo e($this->count); ?></div>
<?php /**PATH C:\xampp\htdocs\style91\resources\views/livewire/cart-count.blade.php ENDPATH**/ ?>