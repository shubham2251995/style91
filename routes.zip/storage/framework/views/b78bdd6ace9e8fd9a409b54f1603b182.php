<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['content']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['content']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    // Defensive data extraction
    $content = $content ?? [];
    
    $getString = function($value) {
        if (is_string($value)) return $value;
        if (is_array($value)) return $value['en'] ?? reset($value) ?? '';
        return (string) $value;
    };

    $title = $getString($content['title'] ?? 'Special Offer');
    $subtitle = $getString($content['subtitle'] ?? 'Limited time only');
    $badge = $getString($content['badge'] ?? '');
    $ctaText = $getString($content['cta_text'] ?? '');
    $ctaUrl = $getString($content['cta_url'] ?? '');
    $imageUrl = $getString($content['image_url'] ?? '');
?>

<section class="px-4">
    <div class="bg-brand-accent rounded-xl p-6 flex justify-between items-center relative overflow-hidden">
        <div class="z-10 flex-1">
            <?php if($badge): ?>
                <span class="bg-white text-brand-dark text-[10px] font-bold px-2 py-1 rounded mb-2 inline-block">
                    <?php echo e($badge); ?>

                </span>
            <?php endif; ?>
            <h3 class="font-black text-2xl text-brand-dark mb-1">
                <?php echo $title; ?>

            </h3>
            <p class="text-brand-dark/80 text-xs mb-4">
                <?php echo e($subtitle); ?>

            </p>
            <?php if($ctaText && $ctaUrl): ?>
                <a href="<?php echo e($ctaUrl); ?>" class="bg-brand-dark text-white px-4 py-2 rounded text-xs font-bold inline-block hover:bg-opacity-90">
                    <?php echo e($ctaText); ?>

                </a>
            <?php endif; ?>
        </div>
        <?php if($imageUrl): ?>
            <img src="<?php echo e($imageUrl); ?>" 
                 class="absolute right-0 bottom-0 w-32 h-32 object-contain drop-shadow-xl" 
                 alt="<?php echo e(strip_tags($title)); ?>">
        <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\style91\resources\views/components/sections/banner.blade.php ENDPATH**/ ?>