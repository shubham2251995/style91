<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['content', 'title']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['content', 'title']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $categories = $content['categories'] ?? [];
    
    $getString = function($value) {
        if (is_string($value)) return $value;
        if (is_array($value)) return $value['en'] ?? reset($value) ?? '';
        return (string) $value;
    };
?>

<section class="px-4">
    <?php if($title): ?>
        <h3 class="font-bold text-lg mb-4 text-brand-dark"><?php echo e($getString($title)); ?></h3>
    <?php endif; ?>
    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $catName = $getString($cat['name'] ?? 'Category');
                $catUrl = $getString($cat['url'] ?? '#');
                $catImage = $getString($cat['image_url'] ?? 'https://source.unsplash.com/random/100x100/?fashion');
            ?>
            <a href="<?php echo e($catUrl); ?>" class="flex flex-col items-center gap-2">
                <div class="w-16 h-16 rounded-full bg-white border-2 border-brand-accent p-1">
                    <div class="w-full h-full rounded-full bg-gray-200 overflow-hidden">
                        <img src="<?php echo e($catImage); ?>" 
                             class="w-full h-full object-cover"
                             alt="<?php echo e($catName); ?>">
                    </div>
                </div>
                <span class="text-xs font-bold text-brand-dark text-center"><?php echo e($catName); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\style91\resources\views/components/sections/categories.blade.php ENDPATH**/ ?>