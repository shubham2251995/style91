<div class="bg-brand-white text-brand-black relative pb-20">
    
    <script type="application/ld+json">
    {
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": "Static Name",
        "image": "Static Image",
        "description": "Static Description",
        "brand": {
            "@type": "Brand",
            "name": "Static Brand"
        },
        "offers": {
            "@type": "Offer",
            "price": "100",
            "priceCurrency": "USD",
            "availability": "https://schema.org/InStock",
            "url": "http://example.com"
        }
    }
    </script>
    
</div>
<?php /**PATH C:\xampp\htdocs\style91\resources\views/test-syntax.blade.php ENDPATH**/ ?>