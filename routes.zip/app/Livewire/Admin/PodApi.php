<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class PodApi extends Component
{
    public function render()
    {
        return view('livewire.admin.pod-api')->layout('components.layouts.admin');
    }
}
