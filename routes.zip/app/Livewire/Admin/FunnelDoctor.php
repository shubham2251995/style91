<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class FunnelDoctor extends Component
{
    public function render()
    {
        return view('livewire.admin.funnel-doctor')->layout('components.layouts.admin');
    }
}
