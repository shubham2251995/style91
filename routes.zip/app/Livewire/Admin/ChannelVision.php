<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class ChannelVision extends Component
{
    public function render()
    {
        return view('livewire.admin.channel-vision')->layout('components.layouts.admin');
    }
}
