<?php

namespace App\Livewire;

use Livewire\Component;

class DropRadar extends Component
{
    public function render()
    {
        return view('livewire.drop-radar')->layout('components.layouts.app');
    }
}
